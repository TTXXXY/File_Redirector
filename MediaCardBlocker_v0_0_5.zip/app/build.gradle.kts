plugins {
    alias(libs.plugins.android.application)
}

kotlin {
    jvmToolchain(17)
}

android {
    namespace   = "ttxxxy.fuck.mediacard"
    compileSdk  = 37

    defaultConfig {
        applicationId = "ttxxxy.fuck.mediacard"
        minSdk        = 28
        targetSdk     = 37
        versionCode   = 20260608
        versionName   = "0.0.4"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        resValues   = false
        buildConfig = false
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    compileOnly(libs.xposed.api) {
        isTransitive = false
    }
}
