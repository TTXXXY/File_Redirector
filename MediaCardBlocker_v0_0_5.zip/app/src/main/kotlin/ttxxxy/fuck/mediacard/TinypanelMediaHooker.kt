package ttxxxy.fuck.mediacard

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

/**
 * 澎湃 OS 通知面板媒体大卡片全量屏蔽器。
 *
 * ─────────────────────────────────────────────
 * 完整调用链（DEX 字节码逐条验证，v16_03_251211）
 * ─────────────────────────────────────────────
 *
 *   TinyKeyguardPanelViewControllerImpl.<init>
 *     → new FlipRowContainerController$2        // 实现 MediaDataManager.Listener
 *     → LegacyMediaDataManagerImpl.addListener($2)
 *
 *   媒体会话变化时，LegacyMediaDataManagerImpl 回调：
 *   FlipRowContainerController$2.onMediaDataLoaded(key, oldKey, MediaData, immediately)
 *     ├─ MediaSortUtils.removeMediaData(key)
 *     ├─ MediaSortUtils.getTopMediaData()
 *     ├─ FlipNotifDataStore.onMediaUpdate(MediaData)   // 路径 A → postValue → 卡片
 *     ├─ [循环] FlipNotifDataStore.onMediaUpdate(...)  // 路径 B → 其他项回退
 *     └─ RecyclerView$Adapter.notifyItemChanged(0)     // 路径 C → 直接刷新 Adapter
 *
 * ─────────────────────────────────────────────
 * v0.0.3 失效原因
 * ─────────────────────────────────────────────
 *
 * v0.0.3 Hook 的是 FlipNotifDataStore.onMediaUpdate，
 * 但字节码证明 onMediaDataLoaded 内部存在路径 C：
 * 直接调用 RecyclerView$Adapter.notifyItemChanged(0)，
 * 完全绕过 onMediaUpdate，导致卡片仍然出现。
 *
 * ─────────────────────────────────────────────
 * 正确拦截策略
 * ─────────────────────────────────────────────
 *
 * Hook FlipRowContainerController$2.onMediaDataLoaded，
 * 在入口处直接 return，路径 A / B / C 全部短路，卡片不渲染。
 *
 * onMediaDataRemoved 无需处理：
 * 由于 onMediaDataLoaded 从未让任何数据进入 FlipNotifDataStore，
 * DataStore 始终为空，onMediaDataRemoved 内调用的 onMediaUpdate(null) 无害。
 *
 * ─────────────────────────────────────────────
 * 副作用
 * ─────────────────────────────────────────────
 *
 * 无。MediaSession 本身不受影响，第三方播放器（含歌词类应用）
 * 通过 MediaController / MediaSessionManager 直接监听，
 * 完全绕过 FlipNotifDataStore，不受此 Hook 影响。
 */
object TinypanelMediaHooker {

    private const val TAG = "PanelBlocker"

    // FlipRowContainerController 里唯一实现 MediaDataManager.Listener 的匿名类
    // DEX 字节码验证：class_data 中 virtual_methods 包含 onMediaDataLoaded 和 onMediaDataRemoved
    private const val CLASS_LISTENER =
        "com.android.notification.tinypanel.FlipRowContainerController\$2"

    private const val CLASS_MEDIA_DATA =
        "com.android.systemui.media.controls.shared.model.MediaData"

    fun hook(classLoader: ClassLoader) {

        val listenerClass = try {
            classLoader.loadClass(CLASS_LISTENER)
        } catch (_: ClassNotFoundException) {
            log("FlipRowContainerController\$2 不存在，非澎湃设备，跳过")
            return
        }

        val mediaDataClass = try {
            classLoader.loadClass(CLASS_MEDIA_DATA)
        } catch (_: ClassNotFoundException) {
            log("MediaData 类加载失败，可能是澎湃版本结构变化，跳过")
            return
        }

        // Hook onMediaDataLoaded，签名（字节码验证）：
        //   (String key, String oldKey, MediaData data, boolean immediately) → void
        // 在入口直接 return，路径 A / B / C 全部短路。
        try {
            XposedHelpers.findAndHookMethod(
                listenerClass,
                "onMediaDataLoaded",
                String::class.java,
                String::class.java,
                mediaDataClass,
                Boolean::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = Unit
                    }
                }
            )
            log("onMediaDataLoaded Hook 成功 ✅")
        } catch (t: Throwable) {
            log("onMediaDataLoaded Hook 失败：${t.message}")
        }
    }

    private fun log(msg: String) {
        XposedBridge.log("[$TAG] $msg")
    }
}
