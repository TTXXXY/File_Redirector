package ttxxxy.fuck.mediacard

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * Xposed 模块入口。
 *
 * 澎湃 OS 把通知面板（tinypanel）跑在 miui.systemui.plugin 独立进程里，
 * FlipRowContainerController$2 等目标类都在这个进程的 classLoader 中，
 * 不在 com.android.systemui 主进程。需要同时注入两个进程。
 *
 * LSPosed 用户：在模块管理页面的作用域里同时勾选
 * 「系统界面（SystemUI）」和「miui.systemui.plugin」。
 */
class HookEntry : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        when (lpparam.packageName) {
            "com.android.systemui",
            "miui.systemui.plugin" -> TinypanelMediaHooker.hook(lpparam.classLoader)
        }
    }
}
